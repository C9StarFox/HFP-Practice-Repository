from distutils.core import setup

setup(
        name            = 'nester',
        version         = '1.0.0',
        py_modules      = ['nester'],
        author          = 'c9starf0x',
        author_email    = 'c9starf0x@gmail.com',
        url             = 'http://www.facebook.com',
        description     = 'A printer of nested lists',
    )
